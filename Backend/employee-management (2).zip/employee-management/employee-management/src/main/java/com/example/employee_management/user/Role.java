
package com.example.employee_management.user;

public enum Role {
    ADMIN,
    EMPLOYEE
}
