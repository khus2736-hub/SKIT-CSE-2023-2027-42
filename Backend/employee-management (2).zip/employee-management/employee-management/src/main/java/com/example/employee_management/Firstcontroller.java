package com.example.employee_management;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Firstcontroller {
    @GetMapping("/api/test")
    public String test() {
        return "Protected API accessed successfully!";
    }
}




































